<?php

\Bitrix\Main\Loader::registerAutoLoadClasses("p10102022_paycode2022", array());
