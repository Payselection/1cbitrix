<?php

\Bitrix\Main\Loader::registerAutoLoadClasses("p10102022_PayCode2022", array());
