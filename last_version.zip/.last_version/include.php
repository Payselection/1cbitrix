<?php

\Bitrix\Main\Loader::registerAutoLoadClasses("p10102022_p10102022paycode2022", array());
