<?
$MESS["SALE_PAYSELECTION_CHECKOUT_MODE"] = "Payment page";
$MESS["SALE_PAYSELECTION_ERROR_STATUS"] = "Incorrect setup status: #STATUS#";
$MESS["SALE_PAYSELECTION_ERROR_SUM"] = "Payment amount does not match amount payable";
$MESS["SALE_PAYSELECTION_REFUND_REASON"] = "Reason for refund not specified";
$MESS["SALE_PAYSELECTION_RESPONSE_DECODE_ERROR"] = "Error decoding JSON string";
$MESS["SALE_PAYSELECTION_TRANSACTION"] = "Transaction #ID#";
$MESS["SALE_PAYSELECTION_WIDGET_MODE"] = "Widget";
?>