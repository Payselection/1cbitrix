<?
$arModuleVersion = array(
    "VERSION" => "1.0.3",
    "VERSION_DATE" => "2022-12-28 10:00:00"
);
