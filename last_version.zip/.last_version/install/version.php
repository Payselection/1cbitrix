<?
$arModuleVersion = array(
    "VERSION" => "1.0.4",
    "VERSION_DATE" => "2023-04-18 10:00:00"
);
