<?
$arModuleVersion = array(
    "VERSION" => "1.0.2",
    "VERSION_DATE" => "2022-11-08 10:00:00"
);
